import React from "react";
import "../../css/Header.css";
const Warehouse = () => {
  return (
    <div id="Notfound">
      <h1>Warehouse</h1>{" "}
    </div>
  );
};

export default Warehouse;
