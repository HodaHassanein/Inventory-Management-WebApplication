import React from "react";
import "../css/Header.css";
const Notfound = () => {
  return (
    <div id="Notfound">
      <h1>404 page Notfound</h1>{" "}
    </div>
  );
};

export default Notfound;
